const express = require('express'); // Importa o módulo express, que é um framework de Node.js para construir aplicações web.
let app = express(); // Cria uma instância do express, que será usada para configurar e iniciar o servidor.

app.use(express.static(".")); // Configura o express para servir arquivos estáticos (HTML, CSS, JS, imagens, etc.) a partir do diretório atual (".").

app.get("/", (req, res) => { // Define uma rota para o caminho raiz ("/"). Quando um cliente faz uma solicitação GET para "/", a função de callback é executada.
    res.sendFile(__dirname + '/index.html'); // Envia o arquivo 'index.html' como resposta. __dirname é uma variável que contém o caminho do diretório onde o script atual está sendo executado.
});

app.listen("3000", () => { // Inicia o servidor na porta 3000. O callback é executado quando o servidor começa a escutar nessa porta.
    console.log("Server is listening on port 3000"); // Exibe uma mensagem no console informando que o servidor está escutando na porta 3000.
});
